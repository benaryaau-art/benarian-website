BENARIAN WEBSITE — DEPLOYMENT

1. Open this folder and double-click index.html to preview.
2. To publish on Netlify:
   - Log in to Netlify.
   - Choose “Add new site” > “Deploy manually”.
   - Drag the entire benarian-site folder into Netlify.
3. After publishing, add BENARIAN.com under Domain Management and follow Netlify’s DNS instructions.

IMPORTANT
- The site is responsive and works on desktop, tablet, and mobile.
- Replace social-media links marked href="#" with your real profile URLs.
- Replace partnerships@benarian.com with your preferred email if needed.
- The homepage currently uses high-quality online images. Your own AYANA videos can later replace the hero background.
