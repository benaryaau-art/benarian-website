
document.querySelectorAll('.booking-tabs button').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.booking-tabs button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  });
});
document.querySelector('.booking-panel')?.addEventListener('submit', e => {
  e.preventDefault();
  alert('Booking search will be connected in the next phase.');
});
