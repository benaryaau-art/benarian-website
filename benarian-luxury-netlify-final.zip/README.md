# BENARIAN Luxury Website

Static HTML/CSS/JS website prepared for GitHub + Netlify.

## Deploy
1. Upload all files to your GitHub repository root.
2. Netlify will deploy automatically.
3. No build command is required.

The founder portrait appears only on `about.html`.
